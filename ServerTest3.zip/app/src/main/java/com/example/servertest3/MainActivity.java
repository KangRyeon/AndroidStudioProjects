package com.example.servertest3;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.servertest3.R;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements Runnable {

    private Button newfile_btn;
    private Button send_btn;
    private TextView txt_view;
    String str;

    //안드로이드 내 저장 파일 이름
    String files;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newfile_btn = (Button) findViewById(R.id.newfile_btn);
        send_btn = (Button) findViewById(R.id.send_btn);
        txt_view = (TextView) findViewById(R.id.txt_view);
        //files=getApplicationContext().getFilesDir().getPath().toString() +"/test.txt";
        files = "/data/data/com.example.servertest3/files/test.txt";
        newfile_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // data/data/패키지이름/files/ 내부메모리 경로
                File file=new File(files);

                // 파일을 생성한다
                try{
                    Log.d("파일생성 : ", files);
                    FileOutputStream fos =new FileOutputStream(file);
                    String str="파일 업로드 테스트";
                    // 스트링.getBytes() : 스트링을 바이트 배열로 변환
                    fos.write(str.getBytes()); //파일이 저장됨
                    fos.close(); //스트림 닫기
                    Toast.makeText(MainActivity.this, "저장 되었습니다.", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        // 버튼을 눌렀을때 thread 실행 -> Override한 run() 함수를 실행시킴. -> run()함수는 실행할 것을 한 뒤 handler 실행
        send_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread th = new Thread(MainActivity.this);
                th.start();
            }
        });
    }

    // handler = 백그라운드 thread에서 전달된 메시지 처리(UI변경 등을 여기서 해줌.)
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            txt_view.setText(str);
        }
    };


    String lineEnd = "\r\n";
    String twoHyphens = "--";
    String boundary = "*****";

    @Override
    public void run() {
        StringBuffer sb = new StringBuffer();
        Log.d("버튼 눌림", "버튼 눌림");
            try {
                String urlString = "http://192.168.55.193:8080/uploadFile";
                String params = "";
                String fileName = "/data/data/com.example.servertest3/files/test.txt";
                URL connectUrl = new URL(urlString);

                try {
                    File sourceFile = new File(fileName);
                    DataOutputStream dos;

                    if (!sourceFile.isFile()) {
                        Log.e("uploadFile", "Source File not exist :" + fileName);
                    } else {
                        FileInputStream mFileInputStream = new FileInputStream(sourceFile);
                        // open connection
                        HttpURLConnection conn = (HttpURLConnection) connectUrl.openConnection();
                        conn.setDoInput(true);
                        conn.setDoOutput(true);
                        conn.setUseCaches(false);
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Connection", "Keep-Alive");
                        conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                        conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                        conn.setRequestProperty("uploaded_file", fileName);

                        // write data
                        dos = new DataOutputStream(conn.getOutputStream());
                        dos.writeBytes(twoHyphens + boundary + lineEnd);
                        dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);
                        dos.writeBytes(lineEnd);

                        int bytesAvailable = mFileInputStream.available();
                        int maxBufferSize = 1024 * 1024;
                        int bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        byte[] buffer = new byte[bufferSize];
                        int bytesRead = mFileInputStream.read(buffer, 0, bufferSize);

                        // read image
                        while (bytesRead > 0) {
                            dos.write(buffer, 0, bufferSize);
                            bytesAvailable = mFileInputStream.available();
                            bufferSize = Math.min(bytesAvailable, maxBufferSize);
                            bytesRead = mFileInputStream.read(buffer, 0, bufferSize);
                        }

                        dos.writeBytes(lineEnd);
                        dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
                        mFileInputStream.close();

                        dos.flush(); // finish upload...

                        if (conn.getResponseCode() == 200) {
                            InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                            BufferedReader reader = new BufferedReader(tmp);
                            StringBuffer stringBuffer = new StringBuffer();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                stringBuffer.append(line);
                            }
                        }


                        mFileInputStream.close();


                        dos.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                str = "다전송함";
            } catch (Exception e) {
                Log.d("Test", "exception " + e.getMessage());
                // TODO: handle exception
            }

        handler.sendEmptyMessage(0);
    }

    /*
    @Override
    public void run() {
        StringBuffer sb = new StringBuffer();
        Log.d("버튼 눌림", "버튼 눌림");


        try {
            FileInputStream fis =new FileInputStream(files);
            URL url = new URL("http://192.168.55.193:8080/andoridUpload");       // 스프링프로젝트의 home.jsp 주소
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();       // URL 연결한 객체 생성
            if (conn != null) {
                //conn.setConnectTimeout(5000);                                        // 연결을 얼마동안 유지할지
                conn.setUseCaches(false);                                           // 캐시데이터 받을지 유무
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=files");

                Log.d("연결 설정", "완료");

                DataOutputStream dos =new DataOutputStream(conn.getOutputStream());
                dos.writeBytes("--files\r\n"); // --은 파일 시작 알림 표시
                dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\""+files+"\""+"\r\n");
                dos.writeBytes("\r\n");//줄바꿈 문자

                Log.d("데이터 연결 설정", "완료");
                // 웹페이지 결과가 파라미터값에 따라 달라지기 때문에 동적으로 생성된 페이지를 가져오게 됨.
                Log.d("데이터 연결 설정", ""+conn.getResponseCode());
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {         // HTTP_OK라면 연결이 잘 된것.
                    int bytes=fis.available();
                    int maxBufferSize=1024;
                    //Math.min(A, B)둘중 작은값;
                    int bufferSize =Math.min(bytes, maxBufferSize);
                    byte[] buffer=new byte[bufferSize];
                    int read=fis.read(buffer, 0, bufferSize);
                    Log.d("파일", "보내려 함");
                    while(read >0){
                        //서버에 업로드
                        dos.write(buffer,0, bufferSize);
                        bytes=fis.available();
                        bufferSize=Math.min(bytes, maxBufferSize);
                        //읽은 바이트 수
                        read=fis.read(buffer, 0, bufferSize);
                        Log.d("파일보냄", ""+read);
                    }
                    dos.writeBytes("\r\n");//줄바꿈 문자

                    dos.writeBytes("--files--\r\n");
                    fis.close();//스트림 닫기
                    dos.flush();//버퍼 클리어
                    dos.close();//출력 스트림 닫기

                    //서버의 응답을 처리
                    int ch;
                    InputStream is=conn.getInputStream(); //입력스트림
                    StringBuffer sb2=new StringBuffer();
                    while( (ch=is.read()) != -1){ // 내용이 없을 때까지 반복
                        sb2.append((char)ch); // 문자를 읽어서 저장
                    }
                    // 스트링.trim() 스트링의 좌우 공백 제거
                    str = sb2.toString().trim();
                    if(str.equals("success")){
                        str = "파일이 업로드되었습니다.";
                    }else if(str.equals("fail")){
                        str = "파일 업로드 실패...";
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtResult.setText(str);
                            Toast.makeText(UploadActivity.this,
                                    "업로드되었습니다.", Toast.LENGTH_SHORT).show();
                        }
                    });

                    is.close();
                }

                conn.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.d("myLog_error", "에러발생했습니다...");
        }

        //str = sb.toString();
        //str = "스프링으로 전송했어요";
        handler.sendEmptyMessage(0);
    }
    */
}

